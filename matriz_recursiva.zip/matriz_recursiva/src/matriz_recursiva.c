/*
 ============================================================================
 Name        : matriz_recursiva.c
 Author      : Martin Monzon, Jorge Estigarribia
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

struct position{
    int row;
    int column;
};

int** arraymaker(int m,int n)
{
		int len=0;
	    int *ptr, **arr;
	    int i;

	    len = sizeof(int *) * m + sizeof(int) * n * m;
	    arr = (int **)malloc(sizeof(len));

	    // ptr is now pointing to the first element in of 2D array
	    ptr = (int *)(arr + m);

	    // for loop to point rows pointer to appropriate location in 2D array
	    for(i = 0; i < m; i++)
	        arr[i] = (ptr + n * i);

	    return arr;
}
void printArray(int **array,int m,int n)
{
	int count=0,i,j;
	srand(time(NULL));
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			array[i][j] = rand()%10;

	for (i = 0; i < m; i++)
	{	if(i>=1)
		printf("\n");
		for (j = 0; j < n; j++)
	        printf("%d ", array[i][j]);
	}
	printf("\n");
}

void printVector(int *vector,struct position size){
    puts("\0");
    for(int i=0;i<size.row+size.column;i++){
        if (vector[i]!=0)
        {
            printf(" %i ",vector[i]);
        }

    }
}

/*void pathing(int **input,int *outputCopy,int index, int x, int y,int xMax,int yMax,struct position size)
{
	//outputCopy[index] = input[x][y];
	if(x == xMax && y == yMax)
	{
		outputCopy[index]=input[x][y];
		printVector(outputCopy,size);
		outputCopy[index]=0;
		return;
	}
	if(x < xMax)
	{
		outputCopy[index]=input[x][y];
		pathing(input, outputCopy,index,x+1, y,xMax,yMax,size);
		outputCopy[index]=0;
	}
	if(y < yMax)
	{
		outputCopy[index]=input[x][y];
		pathing(input, outputCopy,index,x, y+1,xMax,yMax,size);
		outputCopy[index]=0;
	}
	if(x < xMax && y < yMax)
	{
		outputCopy[index]=input[x][y];
		pathing(input, outputCopy,index,x+1, y+1,xMax,yMax,size);
		outputCopy[index]=0;
	}
}*/
void pathing2(int **input,int *outputCopy,int index,struct position size,int iZero,int jZero)
{
    if(iZero==((size.row)-1) && jZero==(size.column-1)){
        outputCopy[index]=input[iZero][jZero];
        printVector(outputCopy,size);
        outputCopy[index]=0;
    }else{
        if(iZero+1<size.row){
            outputCopy[index]=input[iZero][jZero];
            pathing2(input,outputCopy,index+1,size,iZero+1,jZero);
            outputCopy[index]=0;
        }
        if(jZero+1<size.column){
            outputCopy[index]=input[iZero][jZero];
            pathing2(input,outputCopy,index+1,size,iZero,jZero+1);
            outputCopy[index]=0;
        }
        if(iZero+1<size.row && jZero+1<size.column){
            outputCopy[index]=input[iZero][jZero];
            pathing2(input,outputCopy,index+1,size,iZero+1,jZero+1);
            outputCopy[index]=0;
        }
    }
}
/*void freeM(int** matrix,int m)
{
	int i;
	for(i=0;i<m;i++)
		{
			free(matrix[i]);
		}
}*/
int main(void)
{
	struct position size;
	int **matrix,xini,yini,*outputCopy,arrayLenght,index;
	printf("Ingrese la cantidad de filas: ");
	scanf("%d",&size.row);
	printf("Ingrese la cantidad de columnas: ");
	scanf("%d",&size.column);
	arrayLenght=size.row*size.column;
	outputCopy=(int*)calloc(arrayLenght,sizeof(int));
	index=0;
	xini=0;
	yini=0;
	printf("Su matriz de %dx%d:\n",size.row,size.column);
	matrix=arraymaker(size.row,size.column);
	printArray(matrix,size.row,size.column);
	printf("Recorridos posibles: \n");
	pathing2(matrix,outputCopy,index,size,xini,yini);
	free(matrix);
	free(outputCopy);
	return 0;
}
